import math

from os.path import join as pjoin
from collections import OrderedDict

import torch
import torch.nn as nn
import torch.nn.functional as F


class MultiScaleFusionBlock(nn.Module):
    def __init__(self, in_channels):
        super(MultiScaleFusionBlock, self).__init__()

        # 四个并行分支，使用不同扩张率的空洞卷积
        self.branch1 = nn.Sequential(
            nn.Conv3d(in_channels, in_channels, kernel_size=3, dilation=1, padding=1),
            nn.ReLU(inplace=True)
        )

        self.branch2 = nn.Sequential(
            nn.Conv3d(in_channels, in_channels, kernel_size=3, dilation=3, padding=3),
            nn.Conv3d(in_channels, in_channels, kernel_size=1),
            nn.ReLU(inplace=True)
        )

        self.branch3 = nn.Sequential(
            nn.Conv3d(in_channels, in_channels, kernel_size=3, dilation=1, padding=1),
            nn.Conv3d(in_channels, in_channels, kernel_size=3, dilation=3, padding=3),
            nn.Conv3d(in_channels, in_channels, kernel_size=1),
            nn.ReLU(inplace=True)
        )

        self.branch4 = nn.Sequential(
            nn.Conv3d(in_channels, in_channels, kernel_size=3, dilation=1, padding=1),
            nn.Conv3d(in_channels, in_channels, kernel_size=3, dilation=3, padding=3),
            nn.Conv3d(in_channels, in_channels, kernel_size=3, dilation=5, padding=5),
            nn.Conv3d(in_channels, in_channels, kernel_size=1),
            nn.ReLU(inplace=True)
        )

        self.fusion = nn.Conv3d(in_channels * 5, in_channels, kernel_size=1)

    def forward(self, x):
        b1 = self.branch1(x)
        b2 = self.branch2(x)
        b3 = self.branch3(x)
        b4 = self.branch4(x)

        # 将所有分支的输出与原始输入拼接
        out = torch.cat([x, b1, b2, b3, b4], dim=1)
        out = self.fusion(out)
        return out